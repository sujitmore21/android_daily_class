package com.example.mylib;

public class Car {

    public void speedCar(){

    }
}
